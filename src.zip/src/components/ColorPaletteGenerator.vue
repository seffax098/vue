<template>
  <div class="palette-page">
    <h2>Генератор цветовых палитр</h2>
    <p class="subtitle">
      Практика 27: случайная генерация, копирование, закрепление, сохранение в localStorage.
    </p>

    <!-- Панель управления -->
    <section class="controls">
      <div class="control-group">
        <label>Количество цветов:</label>
        <select v-model.number="colorCount" class="select-input">
          <option v-for="option in colorCountOptions" :key="option" :value="option">
            {{ option }}
          </option>
        </select>
      </div>

      <div class="control-group">
        <label>Формат отображения:</label>
        <div class="format-toggle">
          <button
            class="format-button"
            :class="{ active: colorFormat === 'hex' }"
            @click="colorFormat = 'hex'"
          >
            HEX
          </button>
          <button
            class="format-button"
            :class="{ active: colorFormat === 'rgb' }"
            @click="colorFormat = 'rgb'"
          >
            RGB
          </button>
        </div>
      </div>

      <div class="control-group">
        <label>Фон превью:</label>
        <button class="toggle-bg" @click="isDarkPreview = !isDarkPreview">
          {{ isDarkPreview ? 'Тёмный фон' : 'Светлый фон' }}
        </button>
      </div>

      <div class="control-group">
        <button class="generate-button" @click="generatePalette">
          🎲 Случайная палитра
        </button>
      </div>
    </section>

    <!-- Основная палитра -->
    <section class="palette">
      <div
        v-for="(color, index) in colors"
        :key="color.id"
        class="color-card"
        :style="{ backgroundColor: color.hex }"
        @click="copyColor(color)"
      >
        <div class="color-header">
          <span class="color-index">#{{ index + 1 }}</span>

          <button
            class="lock-button"
            :class="{ locked: color.locked }"
            @click.stop="toggleLock(color)"
          >
            <span v-if="color.locked">🔒</span>
            <span v-else>🔓</span>
          </button>
        </div>

        <div class="color-value">
          {{ getColorText(color.hex) }}
        </div>

        <div class="color-hint">
          Клик для копирования
        </div>
      </div>
    </section>

    <!-- Уведомление о копировании -->
    <transition name="fade">
      <div v-if="copyMessage" class="copy-toast">
        {{ copyMessage }}
      </div>
    </transition>

    <!-- Превью интерфейса -->
    <section
      class="preview"
      :class="{ dark: isDarkPreview }"
    >
      <h3>Превью интерфейса</h3>
      <p class="preview-text">
        Здесь можно увидеть, как палитра будет смотреться в UI.
      </p>

      <div class="preview-row">
        <button
          class="preview-button"
          :style="{ backgroundColor: colors[0]?.hex || '#3b82f6' }"
        >
          Основная кнопка
        </button>

        <button
          class="preview-button outline"
          :style="{
            color: colors[0]?.hex || '#3b82f6',
            borderColor: colors[0]?.hex || '#3b82f6'
          }"
        >
          Вторичная
        </button>
      </div>

      <div class="preview-card" :style="{ backgroundColor: colors[1]?.hex || '#e5e7eb' }">
        <h4 :style="{ color: getTextColorForBackground(colors[1]?.hex) }">
          Карточка контента
        </h4>
        <p :style="{ color: getTextColorForBackground(colors[1]?.hex, true) }">
          Текст для проверки контраста.
        </p>
      </div>

      <div class="preview-footer" :style="{ borderTopColor: colors[2]?.hex || '#9ca3af' }">
        <span :style="{ color: colors[2]?.hex || '#6b7280' }">
          Акцентный цвет интерфейса
        </span>
      </div>
    </section>
  </div>
</template>

<script>
import { ref, onMounted, watch } from 'vue'

export default {
  name: 'ColorPaletteGenerator',

  setup() {
    const colorCountOptions = [3, 5, 7]
    const colorCount = ref(5)
    const colors = ref([]) // { id, hex, locked }
    const colorFormat = ref('hex') // 'hex' | 'rgb'
    const isDarkPreview = ref(false)

    const copyMessage = ref('')
    let copyTimeoutId = null

    // --- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ---

    const randomHexColor = () => {
      const value = Math.floor(Math.random() * 0xffffff)
      return '#' + value.toString(16).padStart(6, '0').toUpperCase()
    }

    const hexToRgbObject = (hex) => {
      let clean = hex.replace('#', '')
      if (clean.length === 3) {
        clean = clean.split('').map(ch => ch + ch).join('')
      }
      const r = parseInt(clean.slice(0, 2), 16)
      const g = parseInt(clean.slice(2, 4), 16)
      const b = parseInt(clean.slice(4, 6), 16)
      return { r, g, b }
    }

    const hexToRgbString = (hex) => {
      const { r, g, b } = hexToRgbObject(hex)
      return `rgb(${r}, ${g}, ${b})`
    }

    const getLuminance = (hex) => {
      const { r, g, b } = hexToRgbObject(hex)
      const norm = [r, g, b].map(v => {
        const c = v / 255
        return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)
      })
      return 0.2126 * norm[0] + 0.7152 * norm[1] + 0.0722 * norm[2]
    }

    const getTextColorForBackground = (hex, isSecondary = false) => {
      if (!hex) {
        return isSecondary ? '#9CA3AF' : '#111827'
      }
      const L = getLuminance(hex)
      // простая логика: темный фон – светлый текст, и наоборот
      if (L < 0.5) {
        return isSecondary ? '#E5E7EB' : '#F9FAFB'
      } else {
        return isSecondary ? '#4B5563' : '#111827'
      }
    }

    // --- ЛОГИКА ПАЛИТРЫ ---

    const generatePalette = () => {
      const oldColors = colors.value
      const newColors = []

      for (let i = 0; i < colorCount.value; i++) {
        const existing = oldColors[i]

        if (existing && existing.locked) {
          newColors.push(existing)
        } else {
          newColors.push({
            id: existing?.id || Date.now() + i,
            hex: randomHexColor(),
            locked: existing?.locked || false
          })
        }
      }

      colors.value = newColors
      saveToLocalStorage()
    }

    const toggleLock = (color) => {
      color.locked = !color.locked
      saveToLocalStorage()
    }

    const getColorText = (hex) => {
      return colorFormat.value === 'hex' ? hex : hexToRgbString(hex)
    }

    const copyColor = async (color) => {
      const text = getColorText(color.hex)
      try {
        await navigator.clipboard.writeText(text)
        copyMessage.value = `Цвет ${text} скопирован в буфер обмена`
      } catch (e) {
        copyMessage.value = 'Не удалось скопировать цвет'
      }

      if (copyTimeoutId) {
        clearTimeout(copyTimeoutId)
      }
      copyTimeoutId = setTimeout(() => {
        copyMessage.value = ''
      }, 1500)
    }

    // --- LOCALSTORAGE ---

    const STORAGE_KEY = 'vue-color-palette-v1'

    const saveToLocalStorage = () => {
      const data = {
        colors: colors.value,
        colorCount: colorCount.value,
        colorFormat: colorFormat.value,
        isDarkPreview: isDarkPreview.value
      }
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
    }

    const loadFromLocalStorage = () => {
      try {
        const raw = localStorage.getItem(STORAGE_KEY)
        if (!raw) {
          generatePalette()
          return
        }
        const parsed = JSON.parse(raw)

        if (Array.isArray(parsed.colors) && parsed.colors.length > 0) {
          colors.value = parsed.colors
        } else {
          generatePalette()
        }

        if (parsed.colorCount) colorCount.value = parsed.colorCount
        if (parsed.colorFormat) colorFormat.value = parsed.colorFormat
        if (typeof parsed.isDarkPreview === 'boolean') {
          isDarkPreview.value = parsed.isDarkPreview
        }
      } catch (e) {
        // если что-то пошло не так – генерируем новую палитру
        generatePalette()
      }
    }

    // --- WATCHERS ---

    watch(colorCount, () => {
      generatePalette()
    })

    watch([colorFormat, isDarkPreview], () => {
      saveToLocalStorage()
    })

    // --- ЖИЗНЕННЫЙ ЦИКЛ ---

    onMounted(() => {
      loadFromLocalStorage()
    })

    return {
      colorCountOptions,
      colorCount,
      colors,
      colorFormat,
      isDarkPreview,
      copyMessage,
      generatePalette,
      toggleLock,
      getColorText,
      copyColor,
      getTextColorForBackground
    }
  }
}
</script>

<style scoped>
.palette-page {
  max-width: 900px;
  margin: 20px auto 40px;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 12px;
  box-shadow: 0 10px 25px rgba(15, 23, 42, 0.08);
}

.subtitle {
  margin-top: 4px;
  margin-bottom: 20px;
  color: #6b7280;
}

.controls {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  padding: 16px;
  border-radius: 10px;
  background-color: #f9fafb;
  margin-bottom: 20px;
}

.control-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 160px;
}

label {
  font-size: 0.9rem;
  font-weight: 600;
  color: #374151;
}

.select-input {
  padding: 6px 10px;
  border-radius: 6px;
  border: 1px solid #d1d5db;
  font-size: 0.9rem;
}

.format-toggle {
  display: flex;
  gap: 8px;
}

.format-button {
  padding: 6px 12px;
  border-radius: 999px;
  border: 1px solid #d1d5db;
  background-color: white;
  font-size: 0.85rem;
  cursor: pointer;
}

.format-button.active {
  background-color: #4f46e5;
  color: white;
  border-color: #4f46e5;
}

.toggle-bg {
  padding: 6px 12px;
  border-radius: 999px;
  border: 1px solid #d1d5db;
  background-color: white;
  cursor: pointer;
  font-size: 0.85rem;
}

.generate-button {
  padding: 8px 16px;
  border-radius: 999px;
  border: none;
  background: linear-gradient(135deg, #6366f1, #ec4899);
  color: white;
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
}

/* Палитра */
.palette {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
  gap: 12px;
  margin-bottom: 24px;
}

.color-card {
  position: relative;
  border-radius: 10px;
  padding: 10px;
  color: white;
  cursor: pointer;
  min-height: 120px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  box-shadow: 0 8px 18px rgba(15, 23, 42, 0.25);
}

.color-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.color-index {
  font-size: 0.85rem;
  opacity: 0.9;
}

.lock-button {
  width: 28px;
  height: 28px;
  border-radius: 999px;
  border: none;
  background-color: rgba(15, 23, 42, 0.35);
  color: white;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}

.lock-button.locked {
  background-color: rgba(22, 163, 74, 0.8);
}

.color-value {
  font-weight: 700;
  font-size: 0.95rem;
}

.color-hint {
  font-size: 0.8rem;
  opacity: 0.9;
}

/* Уведомление */
.copy-toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  transform: translateX(-50%);
  background-color: #111827;
  color: white;
  padding: 10px 16px;
  border-radius: 999px;
  font-size: 0.9rem;
  box-shadow: 0 10px 30px rgba(15, 23, 42, 0.6);
  z-index: 50;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s, transform 0.2s;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: translate(-50%, 10px);
}

/* Превью */
.preview {
  padding: 18px;
  border-radius: 10px;
  background-color: #f3f4f6;
  border: 1px solid #e5e7eb;
}

.preview.dark {
  background-color: #0f172a;
  border-color: #1e293b;
}

.preview h3 {
  margin-bottom: 4px;
}

.preview-text {
  font-size: 0.9rem;
  color: #6b7280;
  margin-bottom: 16px;
}

.preview.dark .preview-text {
  color: #9ca3af;
}

.preview-row {
  display: flex;
  gap: 10px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.preview-button {
  padding: 8px 16px;
  border-radius: 999px;
  border: none;
  color: white;
  font-size: 0.9rem;
  cursor: pointer;
}

.preview-button.outline {
  background-color: transparent;
  border-width: 1px;
  border-style: solid;
}

.preview.dark .preview-button.outline {
  background-color: rgba(15, 23, 42, 0.4);
}

.preview-card {
  padding: 14px;
  border-radius: 10px;
  margin-bottom: 12px;
}

.preview-footer {
  padding-top: 10px;
  border-top-width: 2px;
  border-top-style: solid;
}
</style>
